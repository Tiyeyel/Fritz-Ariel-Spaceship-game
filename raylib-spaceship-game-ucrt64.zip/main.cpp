#include "raylib.h"

int main() {
    InitWindow(800, 600, "Raylib Spaceship Game");

    SetTargetFPS(60);

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(BLACK);
        DrawText("Hello from raylib!", 250, 280, 20, RAYWHITE);
        EndDrawing();
    }

    CloseWindow();
    return 0;
}
