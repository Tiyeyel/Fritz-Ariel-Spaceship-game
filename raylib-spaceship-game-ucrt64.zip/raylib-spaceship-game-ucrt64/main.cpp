#include "raylib.h"
#include <vector>
#include <cstdlib>  // For rand()

struct Bullet {
    Vector2 position;
    float speed;
    bool active;
};

struct Enemy {
    Vector2 position;
    float speed;
    bool active;
};

int main() {
    const int screenWidth = 800;
    const int screenHeight = 600;

    InitWindow(screenWidth, screenHeight, "Spaceship Game");
    SetTargetFPS(60);

    // Spaceship setup
    Vector2 shipPos = { screenWidth / 2.0f, screenHeight - 50 };
    float shipWidth = 40;
    float shipHeight = 20;
    float shipSpeed = 5.0f;

    // Bullet setup
    std::vector<Bullet> bullets;
    float bulletSpeed = 10.0f;
    float bulletWidth = 5.0f;
    float bulletHeight = 10.0f;

    // Enemy setup
    std::vector<Enemy> enemies;
    float enemySpeed = 2.0f;
    float enemyWidth = 30.0f;
    float enemyHeight = 30.0f;

    int frameCount = 0;
    int enemySpawnRate = 60;  // Ensure enemySpawnRate is an integer
    bool gameOver = false;

    while (!WindowShouldClose() && !gameOver) {
        // --- Update ---
        if (gameOver) break;

        // Move spaceship
        if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) shipPos.x -= shipSpeed;
        if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) shipPos.x += shipSpeed;

        // Keep spaceship within screen bounds
        if (shipPos.x < 0) shipPos.x = 0;
        if (shipPos.x > screenWidth - shipWidth) shipPos.x = screenWidth - shipWidth;

        // Shooting bullets
        if (IsKeyPressed(KEY_SPACE)) {
            Bullet newBullet = { { shipPos.x + shipWidth / 2 - bulletWidth / 2, shipPos.y - bulletHeight }, bulletSpeed, true };
            bullets.push_back(newBullet);
        }

        // Move bullets
        for (size_t i = 0; i < bullets.size(); i++) {
            if (bullets[i].active) {
                bullets[i].position.y -= bullets[i].speed;

                // Deactivate bullet if it goes off-screen
                if (bullets[i].position.y < 0) {
                    bullets[i].active = false;
                }
            }
        }

        // Spawn enemies
        frameCount++;
        if (frameCount % enemySpawnRate == 0) {
            float enemyX = rand() % (screenWidth - (int)enemyWidth);  // Random X position
            Enemy newEnemy = { { enemyX, -enemyHeight }, enemySpeed, true };
            enemies.push_back(newEnemy);
        }

        // Move enemies
        for (size_t i = 0; i < enemies.size(); i++) {
            if (enemies[i].active) {
                enemies[i].position.y += enemies[i].speed;

                // Deactivate enemy if it goes off-screen
                if (enemies[i].position.y > screenHeight) {
                    enemies[i].active = false;
                }

                // Check for collision with spaceship
                if (CheckCollisionRecs(
                        { shipPos.x, shipPos.y, shipWidth, shipHeight }, 
                        { enemies[i].position.x, enemies[i].position.y, enemyWidth, enemyHeight })) {
                    gameOver = true;
                }
            }
        }

        // Check for bullet collisions with enemies
        for (size_t i = 0; i < bullets.size(); i++) {
            if (bullets[i].active) {
                for (size_t j = 0; j < enemies.size(); j++) {
                    if (enemies[j].active && 
                        CheckCollisionRecs(
                            { bullets[i].position.x, bullets[i].position.y, bulletWidth, bulletHeight },
                            { enemies[j].position.x, enemies[j].position.y, enemyWidth, enemyHeight })) {
                        // Deactivate both bullet and enemy
                        bullets[i].active = false;
                        enemies[j].active = false;
                    }
                }
            }
        }

        // --- Draw ---
        BeginDrawing();
        ClearBackground(BLACK);

        // Draw spaceship
        DrawRectangleV(shipPos, {shipWidth, shipHeight}, BLUE);

        // Draw bullets
        for (size_t i = 0; i < bullets.size(); i++) {
            if (bullets[i].active) {
                DrawRectangleV(bullets[i].position, {bulletWidth, bulletHeight}, RED);
            }
        }

        // Draw enemies
        for (size_t i = 0; i < enemies.size(); i++) {
            if (enemies[i].active) {
                DrawRectangleV(enemies[i].position, {enemyWidth, enemyHeight}, GREEN);
            }
        }

        // Draw game over message if game is over
        if (gameOver) {
            DrawText("GAME OVER!", screenWidth / 2 - 100, screenHeight / 2 - 20, 40, RED);
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}

